# Compile eeg binary natively for 4 cores
cd ~/eeg_par
#make clean
NUM_THREADS=4 make native
# Run native binary
./eeg > ~/eeg_par/eeg_native.txt
# Check if results match
sed -n -e '/^Feature/p' ~/eeg_par/eeg_original.txt > ~/eeg_par/compare_original.txt
sed -n -e '/^Feature/p' ~/eeg_par/eeg_native.txt > ~/eeg_par/compare_native.txt

echo
diff -q ~/eeg_par/compare_original.txt ~/eeg_par/compare_native.txt
if [[ $? == "0" ]]
then
  echo "Success!"
  echo "The code returned the same feature values as the original code"
else
  diff ~/eeg_par/compare_original.txt ~/eeg_par/compare_native.txt
fi
rm ~/eeg_par/compare_original.txt ~/eeg_par/compare_native.txt
