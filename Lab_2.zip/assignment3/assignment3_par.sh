# Remove previous runs
rm -Rf ~/gem5/configs/assignment3
rm -Rf ~/eeg_par/assignment3
# Create output folders for simulation
mkdir -p ~/eeg_par/assignment3/m5out
mkdir -p ~/eeg_par/assignment3/configs
# Compile eeg binary for 4 cores and copy to assignment3 folder
cd ~/eeg_par
NUM_THREADS=4 make
cp ~/eeg_par/eeg.arm ~/eeg_par/assignment3/eeg.arm
# Run simulation
~/gem5/build/ARM/gem5.opt -d ~/eeg_par/assignment3/m5out ~/gem5/configs/example/arm-multicore-A15-A15-A9-A9.py -n 4 -c ~/eeg_par/assignment3/eeg.arm | tee ~/eeg_par/assignment3/m5out/eeg_par.txt

cp ~/gem5/configs/example/arm-multicore-A15-A15-A9-A9.py ~/eeg_par/assignment3/configs/arm-multicore-A15-A15-A9-A9.py
echo "Simulation finished"
