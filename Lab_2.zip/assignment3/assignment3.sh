# Remove previous runs
rm -Rf ~/gem5/configs/assignment3
rm -Rf ~/eeg/assignment3
# Create output folders for simulation
mkdir -p ~/eeg/assignment3/m5out
mkdir -p ~/eeg/assignment3/configs
# Compile eeg binary for 4 cores and copy to assignment3 folder
cd ~/eeg
NUM_THREADS=4 make
cp ~/eeg/eeg.arm ~/eeg/assignment3/eeg.arm
# Run simulation
~/gem5/build/ARM/gem5.opt -d ~/eeg/assignment3/m5out ~/gem5/configs/example/arm-multicore-A15-A15-A9-A9.py -n 4 -c ~/eeg/assignment3/eeg.arm | tee ~/eeg/assignment3/m5out/eeg.txt

cp ~/gem5/configs/example/arm-multicore-A15-A15-A9-A9.py ~/eeg/assignment3/configs/arm-multicore-A15-A15-A9-A9.py
echo "Simulation finished"
