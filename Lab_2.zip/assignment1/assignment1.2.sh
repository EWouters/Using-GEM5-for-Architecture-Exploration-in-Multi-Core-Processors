# Remove previous runs
rm -Rf ~/gem5/configs/assignment1.2
rm -Rf ~/eeg/assignment1.2
# Make directory to put configurations in
mkdir -p ~/gem5/configs/assignment1.2/
# Compile eeg binary and copy to assignment1.2 folder
cd ~/eeg
make
mkdir -p ~/eeg/assignment1.2/configs/
cp ~/eeg/eeg.arm ~/eeg/assignment1.2/eeg.arm
# Copy example config to folder
cp ~/gem5/configs/example/armA9.py ~/gem5/configs/assignment1.2/armA9.py
# Disable L2 Cache
sed -i 's/options.l2cache = 1/options.l2cache = 0/' ~/gem5/configs/assignment1.2/armA9.py
# Set L1 i and d cache size to 2kB
sed -i "s/options.l1i_size = \"32kB\"/options.l1i_size = \"2kB\"/" ~/gem5/configs/assignment1.2/armA9.py
sed -i "s/options.l1d_size = \"32kB\"/options.l1d_size = \"2kB\"/" ~/gem5/configs/assignment1.2/armA9.py

# Vary L1 i and d cache associativity level from 1 to 8
for L1ASSOC in {1..8}; do
    # create config
    cp ~/gem5/configs/assignment1.2/armA9.py ~/gem5/configs/assignment1.2/armA9_assignment1.2_$L1ASSOC.py
    sed -i "s/options.l1i_assoc = 4/options.l1i_assoc = $L1ASSOC/" ~/gem5/configs/assignment1.2/armA9_assignment1.2_$L1ASSOC.py
    sed -i "s/options.l1d_assoc = 4/options.l1d_assoc = $L1ASSOC/" ~/gem5/configs/assignment1.2/armA9_assignment1.2_$L1ASSOC.py
    echo "created config for $L1ASSOC"
    # Create output folder for simulation
    mkdir -p ~/eeg/assignment1.2/m5out_$L1ASSOC
    # Run simulation
    cd ~/eeg
    ~/gem5/build/ARM/gem5.opt -d ~/eeg/assignment1.2/m5out_$L1ASSOC ~/gem5/configs/assignment1.2/armA9_assignment1.2_$L1ASSOC.py -n 1 -c ~/eeg/assignment1.2/eeg.arm | tee ~/eeg/assignment1.2/m5out_$L1ASSOC/eeg.txt &
done

wait
cp -R ~/gem5/configs/assignment1.2/. ~/eeg/assignment1.2/configs/
echo "Simulation finished"
