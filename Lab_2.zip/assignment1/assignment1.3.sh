# Remove previous runs
rm -Rf ~/gem5/configs/assignment1.3
rm -Rf ~/eeg/assignment1.3
# Make directory to put configurations in
mkdir -p ~/gem5/configs/assignment1.3/
# Compile eeg binary and copy to assignment1.3 folder
cd ~/eeg
make
mkdir -p ~/eeg/assignment1.3/configs/
cp ~/eeg/eeg.arm ~/eeg/assignment1.3/eeg.arm
# Copy example config to folder
cp ~/gem5/configs/example/armA9.py ~/gem5/configs/assignment1.3/armA9.py
# Set L1 i and d cache size to 1kB
sed -i "s/options.l1i_size = \"32kB\"/options.l1i_size = \"1kB\"/" ~/gem5/configs/assignment1.3/armA9.py
sed -i "s/options.l1d_size = \"32kB\"/options.l1d_size = \"1kB\"/" ~/gem5/configs/assignment1.3/armA9.py
# Set direct mapped i and d L1 cache
sed -i 's/options.l1i_assoc = 4/options.l1i_assoc = 1/' ~/gem5/configs/assignment1.3/armA9.py
sed -i 's/options.l1d_assoc = 4/options.l1d_assoc = 1/' ~/gem5/configs/assignment1.3/armA9.py
# Set direct mapped L2 cache
sed -i 's/options.l2_assoc = 4/options.l2_assoc = 1/' ~/gem5/configs/assignment1.3/armA9.py


# Vary L2 cache cache size from 2kB to 16Kb
for L2SIZE in 2kB 4kB 8kB 16kB; do
    # create config
    cp ~/gem5/configs/assignment1.3/armA9.py ~/gem5/configs/assignment1.3/armA9_assignment1.3_$L2SIZE.py
    sed -i "s/options.l2_size = \"256kB\"/options.l2_size = \"$L2SIZE\"/" ~/gem5/configs/assignment1.3/armA9_assignment1.3_$L2SIZE.py
    echo "created config for $L2SIZE"
    # Create output folder for simulation
    mkdir -p ~/eeg/assignment1.3/m5out_$L2SIZE
    # Run simulation
    cd ~/eeg
    ~/gem5/build/ARM/gem5.opt -d ~/eeg/assignment1.3/m5out_$L2SIZE ~/gem5/configs/assignment1.3/armA9_assignment1.3_$L2SIZE.py -n 1 -c ~/eeg/assignment1.3/eeg.arm | tee ~/eeg/assignment1.3/m5out_$L2SIZE/eeg.txt &
done

wait
cp -R ~/gem5/configs/assignment1.3/. ~/eeg/assignment1.3/configs/
echo "Simulation finished"
