# Remove previous runs
rm -Rf ~/gem5/configs/assignment1.1
rm -Rf ~/eeg/assignment1.1
# Make directory to put configurations in
mkdir -p ~/gem5/configs/assignment1.1/
# Compile eeg binary and copy to assignment1.1 folder
cd ~/eeg
make
mkdir -p ~/eeg/assignment1.1/configs/
cp ~/eeg/eeg.arm ~/eeg/assignment1.1/eeg.arm
# Copy example config to folder
cp ~/gem5/configs/example/armA9.py ~/gem5/configs/assignment1.1/armA9.py
# Disable L2 Cache
sed -i 's/options.l2cache = 1/options.l2cache = 0/' ~/gem5/configs/assignment1.1/armA9.py
# Set direct mapped i and d cache
sed -i 's/options.l1i_assoc = 4/options.l1i_assoc = 1/' ~/gem5/configs/assignment1.1/armA9.py
sed -i 's/options.l1d_assoc = 4/options.l1d_assoc = 1/' ~/gem5/configs/assignment1.1/armA9.py

# Vary L1 i and d cache size from 64B to 64Kb
for L1SIZE in 64B 128B 256B 512B 1024B 1kB 2kB 4kB 8kB 16kB 32kB 64kB; do
    # create config
    cp ~/gem5/configs/assignment1.1/armA9.py ~/gem5/configs/assignment1.1/armA9_assignment1.1_$L1SIZE.py
    sed -i "s/options.l1i_size = \"32kB\"/options.l1i_size = \"$L1SIZE\"/" ~/gem5/configs/assignment1.1/armA9_assignment1.1_$L1SIZE.py
    sed -i "s/options.l1d_size = \"32kB\"/options.l1d_size = \"$L1SIZE\"/" ~/gem5/configs/assignment1.1/armA9_assignment1.1_$L1SIZE.py
    echo "created config for $L1SIZE"
    # Create output folder for simulation
    mkdir -p ~/eeg/assignment1.1/m5out_$L1SIZE
    # Run simulation
    cd ~/eeg
    ~/gem5/build/ARM/gem5.opt -d ~/eeg/assignment1.1/m5out_$L1SIZE ~/gem5/configs/assignment1.1/armA9_assignment1.1_$L1SIZE.py -n 1 -c ~/eeg/assignment1.1/eeg.arm | tee ~/eeg/assignment1.1/m5out_$L1SIZE/eeg.txt &
done

wait
cp -R ~/gem5/configs/assignment1.1/. ~/eeg/assignment1.1/configs/
echo "Simulation finished"
